package school.doel.heapSort;

public interface HeapInterface
{
	public int left (int i);
	public int right (int i);
	public void versickern (int n, int i);
	public void heapify ();
}
